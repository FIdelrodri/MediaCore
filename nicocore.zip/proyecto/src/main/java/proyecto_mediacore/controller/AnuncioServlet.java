package proyecto_mediacore.controller;

import proyecto_mediacore.dao.implementacion.AnuncioDAO;
import proyecto_mediacore.model.Anuncio;
import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

// Esta va a ser la URL de tu API para Postman
@WebServlet("/api/anuncios")
public class AnuncioServlet extends HttpServlet {

    // Instanciamos tu DAO de anuncios y Gson según tus clases reales
    private AnuncioDAO anuncioDAO = new AnuncioDAO();
    private Gson gson = new Gson();

    // 1. ENDPOINT PARA LEER ANUNCIOS (GET)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Configuramos cabeceras JSON y CORS (vital para que no se bloquee)
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");

        try {
            // Usamos tu método exacto de AnuncioDAO
            List<Anuncio> lista = anuncioDAO.listarAnuncios();

            // Convertimos la lista de Java a un texto JSON
            String jsonResponse = this.gson.toJson(lista);

            PrintWriter out = response.getWriter();
            out.print(jsonResponse);
            out.flush();
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().print("{\"error\": \"Error interno al obtener anuncios: " + e.getMessage() + "\"}");
        }
    }

    // 2. ENDPOINT PARA CREAR UN ANUNCIO (POST)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");

        try {
            // Gson lee el JSON que viene del Body de Postman y lo transforma en tu objeto Anuncio
            Anuncio nuevoAnuncio = gson.fromJson(request.getReader(), Anuncio.class);

            // Guardamos el objeto usando tu método exacto de AnuncioDAO
            anuncioDAO.guardarAnuncio(nuevoAnuncio);

            response.setStatus(HttpServletResponse.SC_CREATED); // Estado 201 Created
            response.getWriter().print("{\"mensaje\": \"Anuncio agregado con éxito\"}");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().print("{\"error\": \"Error al procesar el JSON: " + e.getMessage() + "\"}");
        }
    }

    // SOPORTE PARA PETICIONES OPTIONS (Requerido por los navegadores en peticiones CORS)
    @Override
    protected void doOptions(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
        response.setStatus(HttpServletResponse.SC_OK);
    }
}
